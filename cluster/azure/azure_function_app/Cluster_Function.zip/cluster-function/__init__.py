import os
import sys
import json
import asyncio
import traceback
import re
import time
import azure.functions as func
from .azure_utils import get_vmss_info
from .events_and_outputs import (
    ignore_or_process_event, trigger_acknowledge, send_vmss_info, send_message,
    send_retrigger, get_recount, get_configured_asav, get_asadetailsfromqueue, put_configured_asav_to_queue
)
# from .ssh_and_cluster_utils import get_cluster_info
from .asav import ASAvInstance
import logging

MAX_RETRIES = 3
def recall(begin_time):
    current_time = time.time()
    elapsed_time = round(current_time - begin_time, 2)
    if elapsed_time > 400:
        return True
    else:
        return False


#def main(req: func.HttpRequest):

def main(msg: func.QueueMessage):
    try:
        rcount = 0
        begin_time = int(time.time())

        #decide if event is to ignored
        if ignore_or_process_event(msg):
            return

        rcount = get_recount(msg)
        #send message to queue indicating function execution has started
        trigger_acknowledge(msg)

        configured_asav = get_asadetailsfromqueue()
        send_message(msg.id, "Configured ASAv List fetched from queue. {}".format(configured_asav))
        
        #get dict object with relevent fields
        vm_list = get_vmss_info()
        send_vmss_info(msg.id, vm_list)
        config_url = os.environ['ASAV_CONFIG_FILE']
        local_file_name = 'Configuration.txt'
        asav_local_file_path = 'disk0:' + local_file_name

        vmss_vm_ip_list = set()
        for vm in vm_list:
            vmss_vm_ip_list.add(vm_list[vm]['MgmtPublic'])

        for vm in vm_list:
            if vm_list[vm]['Status'] != "VM running":
                send_message(msg.id, "VM {} is not in running state.".format(vm_list[vm]['MgmtPublic']))
                continue

            if vm_list[vm]['MgmtPublic'] in configured_asav:
                send_message(msg.id, "Cluster is already enabled on the ASAv instance {}".format(vm_list[vm]['MgmtPublic']))
                continue

            if recall(begin_time):
                put_configured_asav_to_queue('-'.join(set(configured_asav)))
                send_retrigger(rcount, "Recalling the Function due to time elapse", '-'.join(set(configured_asav)))

            asav_obj = ASAvInstance(vm_list[vm], msg.id)
            for i in range(MAX_RETRIES):
                ssh_status = asav_obj.check_asav_ssh_status()
                send_message(msg.id, "ASAv Connect Status for ASAv {} : {}".format(vm_list[vm]['MgmtPublic'], ssh_status))
                if ssh_status == "SUCCESS":
                    send_message(msg.id, "Connected to the ASAv Instance : {}. Configuring Enable Password".format(vm_list[vm]['MgmtPublic']))
                    for i in range(MAX_RETRIES):
                        check_passwd_status = asav_obj.is_passwd_already_set()
                        if check_passwd_status == "NOT SET":
                            set_pwd_status = asav_obj.set_enable_password() 
                            send_message(msg.id, "Status of Enable Password : {}".format(set_pwd_status))
                            if set_pwd_status == "SUCCESS":
                                send_message(msg.id, "Enable Password Set Successfully")
                                break
                        elif check_passwd_status == "SET":
                            send_message(msg.id, "Enable Password is already set")
                            break
                        else:
                            send_message(msg.id,"Error in configuring enable Password. Retrying...")
                            continue

                    if recall(begin_time):
                        put_configured_asav_to_queue('-'.join(set(configured_asav)))
                        send_retrigger(rcount, "Recalling the Function due to time elapse", '-'.join(set(configured_asav)))

                    send_message(msg.id, "Copying the configuration to the ASAv Instance : {}".format(vm_list[vm]['MgmtPublic']))
                    for i in range(MAX_RETRIES):
                        if asav_obj.verify_configuration_file_copy(local_file_name) == "SUCCESS":
                            send_message(msg.id, "ASAv Configuration has been already applied!")
                            break
                        elif asav_obj.run_copy_file_running_config(config_url, asav_local_file_path) == "SUCCESS":
                            if asav_obj.verify_configuration_file_copy(local_file_name) == "SUCCESS":
                                send_message(msg.id, "ASAv Configuration has been applied!")
                                break

                    if recall(begin_time):
                        put_configured_asav_to_queue('-'.join(set(configured_asav)))
                        send_retrigger(rcount, "Recalling the Function due to time elapse", '-'.join(set(configured_asav)))

                    send_message(msg.id, "Checking the status of the cluster")

                    cluster_status = asav_obj.check_asav_cluster_status()
                    if cluster_status == "NOT ENABLED":
                        send_message(msg.id, "Enabling cluster on the ASAv : {}".format(vm_list[vm]['MgmtPublic']))
                        octet = str(vm_list[vm]['MgmtPrivate'].split('.')[3])
                        for i in range(MAX_RETRIES):
                            if not recall(begin_time):
                                enable_cluster = asav_obj.apply_cluster_config(octet)
                                send_message(msg.id, "Status of the enable Cluster : {}".format(enable_cluster))
                                if enable_cluster == "SUCCESS":
                                    configured_asav.append(vm_list[vm]['MgmtPublic'])
                                    put_configured_asav_to_queue('-'.join(set(configured_asav)))
                                    break
                                else:
                                    send_message(msg.id, "Cluster Configuration failed for the ASAv VM {}. Retrying...".format(vm_list[vm]['MgmtPublic']))
                                    if not recall(begin_time):
                                        time.sleep(10)
                                        continue
                                    else:
                                        put_configured_asav_to_queue('-'.join(set(configured_asav)))
                                        send_retrigger(rcount, "Recalling the Function due to function timeout", '-'.join(set(configured_asav)))
                            else:
                                put_configured_asav_to_queue('-'.join(set(configured_asav)))
                                send_retrigger(rcount, "Recalling the function due to timeout", '-'.join(set(configured_asav)))

                    elif cluster_status == "ENABLED":
                        send_message(msg.id, "Cluster is already enabled on the ASAv : {}".format(vm_list[vm]['MgmtPublic']))
                        configured_asav.append(vm_list[vm]['MgmtPublic'])
                        put_configured_asav_to_queue('-'.join(set(configured_asav)))
                    else:
                        send_message(msg.id, "Error in cluster status check. {}".format(cluster_status))
                    
                    break
                else:
                    send_message(msg.id, "Unable to Connect to the ASAv instance : {}. Retrying...".format(vm_list[vm]['MgmtPublic']))
                    if not recall(begin_time):
                        time.sleep(20)
                    else:
                        put_configured_asav_to_queue('-'.join(set(configured_asav)))
                        send_retrigger(rcount, "Recalling the Function due to function timeout", '-'.join(set(configured_asav)))

        put_configured_asav_to_queue('-'.join(set(configured_asav)))
        send_message(msg.id, "Configured  ASAv : {}".format(configured_asav))
        
        if vmss_vm_ip_list.issubset(set(configured_asav)):
            send_message(msg.id,"Configured all the ASAv Instances in the VMSS!")
        else:
            unconfigured_asav = vmss_vm_ip_list - set(configured_asav)
            send_message(msg.id, "Unable to configure the ASAv instances : {}".format(unconfigured_asav))
            send_retrigger(rcount, "Recalling the function as few of the ASAv instance(s) are not configured", '-'.join(set(configured_asav)))


    except Exception as err:

        send_message(msg.id, "Error Occurred : {} in line : {}".format(err, sys.exc_info()[-1].tb_lineno))
        send_retrigger(rcount, "Retriggering Function due to Error: {} in line : {}".format(err, sys.exc_info()[-1].tb_lineno), '-'.join(set(configured_asav)))
