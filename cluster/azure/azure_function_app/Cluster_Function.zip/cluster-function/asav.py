import os
import time
import paramiko
import json
import socket
# import constant as const
# import utility as utl
import re
import telnetlib
from base64 import b64decode
import logging
import sys
import re
from .events_and_outputs import send_message

ASAV_SSH_PORT = 22

DEFAULT_PASSWORD = "AsAv_ClU3TeR44"
USE_PUBLIC_IP_FOR_SSH = True
DISABLE_USER_NOTIFY_EMAIL = False

def setup_logging(debug_logs="disable"):
    """
    Purpose:    Sets up logging
    Parameters: User input to disable debug logs
    Returns:    logger object
    Raises:
    """
    logging.getLogger("paramiko").setLevel(logging.WARNING)
    logger = logging.getLogger()
    for h in logger.handlers:
        logger.removeHandler(h)
    h = logging.StreamHandler(sys.stdout)
    FORMAT = '%(levelname)s [%(asctime)s] (%(funcName)s)# %(message)s'
    h.setFormatter(logging.Formatter(FORMAT))
    logger.addHandler(h)
    logger.setLevel(logging.DEBUG)
    if debug_logs == "disable":
        logging.disable(logging.DEBUG)
    return logger


def put_line_in_log(var, line_type='dot'):
    """
    Purpose:    This is to help putting lines in logs
    Parameters: Variable to print between lines
    Returns:
    Raises:
    """
    if line_type == 'thick':
        logging.info("======================================== < " + var + " > ========================================")
    if line_type == 'thin':
        logging.info("---------------------------------------- < " + var + " > ----------------------------------------")
    if line_type == 'dot':
        logging.info("........................................ < " + var + " > ........................................")
    return

# Setup Logging
logger = setup_logging("INFO")


class ASAvInstance():
    """
        This is ASAv class, supposed to instantiated only in Configure_ASAv Lambda function
    """
    def __init__(self, vm_info, id):
        # Get User input, works only for Configure_ASAv Lambda function
        # self.user_input = utl.get_user_input_configure_asav()
        # Inherit CiscoEc2Instance class

        self.public_ip = vm_info['MgmtPublic']
        self.private_ip = vm_info['MgmtPrivate']
        self.port = ASAV_SSH_PORT
        self.username = os.environ.get('ASA_USERNAME')
        self.defaultPassword = DEFAULT_PASSWORD
        self.password = os.environ.get('ASA_PASSWORD')
        self.prev_password = DEFAULT_PASSWORD
        self.new_password = os.environ.get('ASA_PASSWORD')
        self.COMMAND_RAN = 'COMMAND_RAN'
        self.SUCCESS = 'SUCCESS'
        self.FAIL = 'FAILURE'
        self.connection = None
        self.id = id

    def connect_asa(self):
        """
        Purpose:    This provides object of ParamikoSSH class
        Parameters:
        Returns:    Class object, None
        Raises:
        """
        if USE_PUBLIC_IP_FOR_SSH and self.public_ip is not None:
            # To SSH ASAv Public IP
            ip_to_connect = self.public_ip
        else:
            if self.private_ip is not None:
                # To SSH ASAv Private IP
                ip_to_connect = self.private_ip
            else:
                send_message(self.id, "Found None for private_ip of the ASAv instance")
                return None

        connect = ParamikoSSH(ip_to_connect, self.port, self.username, self.password, self.id)
        logger.debug(connect)
        return connect

    # Run an independent command on ASAv
    def run_asav_command(self, command):
        """
        Purpose:    To run a single command
        Parameters: command
        Returns:    'FAILURE', 'COMMAND_RAN'
        Raises:
        """
        output, error = '', ''
        cnt_asa = self.connect_asa()
        try:
            status, output, error = cnt_asa.execute_cmd(command)
        except Exception as e:
            send_message(self.id, "Error occurred: {}".format(repr(e)))
            return self.FAIL, output, error
        if status == self.SUCCESS:
            # logger.debug("%s %s %s" % (self.COMMAND_RAN, output, error))
            send_message(self.id,"%s %s %s" % (self.COMMAND_RAN, output, error))
            return self.COMMAND_RAN, output, error
        else:
            #logger.warn("Unable to run command output: %s error: %s" % (output, error))
            send_message(self.id, "Unable to run command output: %s error: %s" % (output, error))
            return self.FAIL, output, error

    def check_asav_cluster_status(self):
        '''
        Purpose:
            Check the cluster status of the ASAv Instance
        Arguments:
            * self - ASAv object
        Return:
            * Cluster info
        '''
        command = "show cluster info"
        verify_cluster_not_enabled_string = "Clustering is not "
        verify_cluster_enabled_string = "Cluster asav-cluster: On"
        max_retries = 3
        try:
            for retry in range(0, max_retries):
                if self.verify_string_match(command, verify_cluster_not_enabled_string) == self.SUCCESS:
                    send_message(self.id, "Cluster status : NOT ENABLED")
                    return "NOT ENABLED"
                elif self.verify_string_match(command, verify_cluster_enabled_string) == self.SUCCESS:
                    send_message(self.id, "Cluster status : ENABLED")
                    return "ENABLED"
            else:
                return self.FAIL
        except Exception as error:
            send_message(self.id, "Exception in check_asav_cluster_status : {}".format(error))
            return self.FAIL

    def apply_cluster_config(self, octet):
        """
        Purpose:    apply cluster configuration
        Parameters: last octet for management ip address
        Returns:    SUCCESS, FAILURE
        Raises:
        """
        local_unit = "local-unit "+octet
        cls_int = "cluster-interface vni1 ip 1.1.1."+octet+" 255.255.255.0"
        cnt_asa = self.connect_asa()
        write_memory_config = 'copy /noconfirm running-config startup-config'
        expected_outcome_write_memory_config = '#'

        command_set = {
            "cmd": [
                {
                    "command": "enable",
                    "expect": "Password:"
                },
                {
                    "command": self.password,
                    "expect": "#"
                },
                {
                    "command": "configure terminal",
                    "expect": "(config)#"
                },
                {
                    "command": "cluster group asav-cluster",
                    "expect":  "#"
                },
                {
                    "command": local_unit,
                    "expect": "#"
                },
                {
                    "command": cls_int,
                    "expect": "#"
                },
                {
                    "command": "priority 1",
                    "expect": "#"
                },
                {
                    "command": "enable noconfirm",
                    "expect": "Local Unit is about to join into cluster"
                },
                {
                    "command": write_memory_config,
                    "expect": expected_outcome_write_memory_config
                }
            ]
        }
        try:
            val = cnt_asa.handle_interactive_session(command_set, self.username, self.password)
        except ValueError as e:
            send_message(self.id, "Error occurred in apply_cluster_config: {}".format(repr(e)))
            return self.FAIL
        else:
            return self.SUCCESS

    def enable_password(self):
        """
        Purpose:    To enable password - ASAv
        Parameters:
        Returns:    'FAILURE', 'COMMAND_RAN'
        Raises:
        """
        cnt_asa = self.connect_asa()
        command_set = {
            "cmd": [
                {
                    "command": "enable",
                    "expect": "Password:"
                },
                {
                    "command": self.password,
                    "expect": "#"
                },
                {
                    "command": "conf t",
                    "expect": "(config)#"
                }
            ]
        }

        try:
            cnt_asa.handle_interactive_session(command_set, self.username, self.password)
        except ValueError as e:
            # logger.error("Error occurred: {}".format(repr(e)))
            send_message(self.id, "Error occurred: {}".format(repr(e)))
            cnt_asa.close()
            return self.FAIL
        else:
            cnt_asa.close()
            return self.SUCCESS

    def is_passwd_already_set(self):
        """
        Purpose : Check if the enable password is already set or not
        Parameters :
        Return : "SET", "NOT SET"
        """
        cnt_asa = self.connect_asa()
        command = "enable"
        status, output, error = cnt_asa.execute_cmd(command)
        cnt_asa.close()
        if status == "SUCCESS" and "not set" in output:
            return "NOT SET"
        elif status == "SUCCESS":
            return "SET"
        else:
            return self.FAIL


    def set_enable_password(self):
        """
        Purpose:    To enable password - ASAv
        Parameters:
        Returns:    'FAILURE', 'COMMAND_RAN'
        Raises:
        """
        cnt_asa = self.connect_asa()
        # The enable password is not set.  Please set it now.
        # Enter  Password: ************
        # Repeat Password: ************
        write_memory_config = 'copy /noconfirm running-config startup-config'
        expected_outcome_write_memory_config = '#'
        command_set = {
            "cmd": [
                {
                    "command": "enable",
                    "expect": "Enter  Password:"
                },
                {
                    "command": self.password,
                    "expect": "Repeat Password:"
                },
                {
                    "command": self.password,
                    "expect": "#"
                },
                {
                    "command": write_memory_config,
                    "expect": expected_outcome_write_memory_config
                },
                {
                    "command": "configure terminal",
                    "expect": "(config)#"
                },
                {
                    "command": "A",
                    "expect": "#"
                }
            ]
        }

        try:
            cnt_asa.handle_interactive_session(command_set, self.username, self.password)
        except ValueError as e:
            send_message(self.id, "Error occurred: {}".format(repr(e)))
            cnt_asa.close()
            return self.FAIL
        else:
            cnt_asa.close()
            return self.SUCCESS


    def check_asav_ssh_status(self):
        """
        Purpose:    To check ASAv SSH is accessible
        Parameters:
        Returns:    SUCCESS, FAILURE
        Raises:
        """
        cnt_asa = self.connect_asa()
        status = cnt_asa.connect(self.username, self.password)
        if status == 'SUCCESS':
            cnt_asa.close()
            return 'SUCCESS'
        elif status == 'Authentication Exception Occurred':
            status = cnt_asa.connect(self.username, self.defaultPassword)
            if status == 'SUCCESS':
                cnt_asa.close()  # As below function triggers interactive shell
                #if self.change_asa_password(cnt_asa, self.defaultPassword, self.password) == 'SUCCESS':
                #    return 'SUCCESS'
                return 'SUCCESS'
            else:
                # logger.error("Unable to authenticate to ASAv instance, please check password!")
                send_message(self.id, "Unable to authenticate to ASAv instance, please check password!")
                return 'FAILURE'
        return 'FAILURE'


    # Polling connectivity to ASAv for specified 'minutes'
    def poll_asav_ssh(self, minutes):
        """
        Purpose:    To poll ASAv for SSH accessibility
        Parameters: Minutes
        Returns:    SUCCESS, TIMEOUT
        Raises:
        """
        logger.info("Checking if instance SSH access is available!")
        if minutes <= 1:
            minutes = 2
        for i in range(1, 2 * minutes):
            if i != ((2 * minutes) - 1):
                status = self.check_asav_ssh_status()
                if status != "SUCCESS":
                    # logger.debug(str(i) + " Sleeping for 30 seconds")
                    send_message(self.id, "{} Sleeping for 30 seconds".format(i))
                    time.sleep(1 * 30)
                else:
                    return "SUCCESS"
        # logger.info("Failed to connect to device retrying... ")
        send_message(self.id,"Failed to connect to device retrying... ")
        return "TIMEOUT"

    # function to set hostname
    def configure_hostname(self):
        """
        Purpose:    To configure hostname on ASAv
        Parameters:
        Returns:    'FAILURE', 'COMMAND_RAN'
        Raises:
        """
        cnt_asa = self.connect_asa()
        cmd = 'hostname ' + self.vm_name
        expected_outcome = self.vm_name + "(config)#"
        write_memory_config = 'copy /noconfirm running-config startup-config'
        expected_outcome_write_memory_config = '#'
        command_set = {
            "cmd": [
                {
                    "command": "enable",
                    "expect": "Password:"
                },
                {
                    "command": self.password,
                    "expect": "#"
                },
                {
                    "command": "conf t",
                    "expect": "(config)#"
                },
                {
                    "command": cmd,
                    "expect": expected_outcome
                },
                {
                    "command": write_memory_config,
                    "expect": expected_outcome_write_memory_config
                }
            ]
        }
        # logger.info("Initiating hostname change of ASAv with command set: "
        #             + json.dumps(command_set, separators=(',', ':')))
        try:
            cnt_asa.handle_interactive_session(command_set, self.username, self.password)
        except ValueError as e:
            # logger.error("Error occurred: {}".format(repr(e)))
            send_message(self.id, "Error occurred: {}".format(repr(e)))
            return self.FAIL
        else:
            return self.SUCCESS

    def get_sn_of_asav(self):
        """
        Purpose:    To get SN of ASAv
        Parameters:
        Returns:    Either SN or N/A
        Raises:
        """
        try:
            command = "show version | include .*[Ss]erial.[Nn]umber:.* " + "\n"
            status, output, error = self.run_asav_command(command)
            output_json = {
                "command": command,
                "status": status,
                "output": output,
                "error": error
            }
            logger.debug(json.dumps(output_json, separators=(',', ':')))
            output = output.replace(" ", "")
            output_list = output.split(":")
            return output_list[1]
        except IndexError as e:
            logger.debug("Error occurred: {}".format(repr(e)))
            logger.error("Unable to get SN of ASAv")
            return 'N/A'
        except Exception as e:
            logger.error("Error occurred: {}".format(repr(e)))
            return 'N/A'

     # function to set password(admin) from prev_password to new_password
    def set_asa_password(self):
        """
        Purpose:    To set password to asa
        Parameters:
        Returns:    SUCCESS, FAILURE
        Raises:
        """
        cnt_asa = self.connect_asa()
        if self.change_asa_password(cnt_asa, self.password, self.new_password) == 'SUCCESS':
            return 'SUCCESS'
        return 'FAILURE'


    # function to change password(admin) from prev_password to new_password
    def change_asa_password(self, cnt_asa, prev_password, new_password):
        """
        Purpose:    To change password from default to user provided
        Parameters: ParamikoSSH class object, Default password, New Password
        Returns:    SUCCESS, None
        Raises:
        """
        cmd1 = 'username ' + self.username + ' password ' + new_password + ' privilege 15'
        cmd2 = 'enable ' + 'password ' + new_password
        write_memory_config = 'copy /noconfirm running-config startup-config'
        expected_outcome_write_memory_config = '#'
        command_set = {
            "cmd": [
                {
                    "command": "enable",
                    "expect": "Password:"
                },
                {
                    "command": prev_password,
                    "expect": "#"
                },
                {
                    "command": "conf t",
                    "expect": "(config)#"
                },
                {
                    "command": cmd1,
                    "expect": "#"
                },
                {
                    "command": cmd2,
                    "expect": "#"
                },
                {
                    "command": write_memory_config,
                    "expect": expected_outcome_write_memory_config
                }
            ]
        }

        try:
            cnt_asa.handle_interactive_session(command_set, self.username, prev_password)
        except ValueError as e:
            logger.error("Error occurred: {}".format(repr(e)))
            return None
        else:
            return 'SUCCESS'
        finally:
            cnt_asa.close()


    def verify_string_match(self, command, verify_string):
        """
        Purpose:    To verify string match
        Parameters: ParamikoSSH class object, Default password, New Password
        Returns:    SUCCESS, None
        Raises:
        """
        cnt_asa = self.connect_asa()
        command_set = {
            "cmd": [
                {
                    "command": "enable",
                    "expect": "Password:"
                },
                {
                    "command": self.password,
                    "expect": "#"
                },
                {
                    "command": "conf t",
                    "expect": "#"
                },
                {
                    "command": command,
                    "expect": verify_string
                }
            ]
        }
        try:
            cnt_asa.handle_interactive_session(command_set, self.username, self.password)
        except ValueError as e:
            send_message(self.id, "Error occurred(Value Error): {}".format(repr(e)))
            return self.FAIL
        except Exception as e:
            send_message(self.id, "Error occurred(Exception): {}".format(repr(e)))
            return self.FAIL
        else:
            #send_message(self.id, "Found String: {}".format(verify_string))
            return self.SUCCESS
        finally:
            cnt_asa.close()


    def verify_configuration_file_copy(self, local_file_name):
        """
        Purpose:    To verify whether configuration file copied or not
        Parameters: ParamikoSSH class object, Default password, New Password
        Returns:    SUCCESS, None
        Raises:
        """
        command = 'show disk0: '
        verify_string = local_file_name
        return self.verify_string_match(command, verify_string)


    def verify_asa_license_unregistered(self):
        """
        Purpose:    To verify smart license UNREGISTERED
        Parameters: ParamikoSSH class object, Default password, New Password
        Returns:    SUCCESS, None
        Raises:
        """
        command = 'show license summary'
        verify_string = 'UNREGISTERED'
        return self.verify_string_match(command, verify_string)

    def verify_asa_license_registering(self):
        """
        Purpose:    To verify smart license in REGISTERING state
        Parameters: ParamikoSSH class object, Default password, New Password
        Returns:    SUCCESS, None
        Raises:
        """
        command = 'show license summary'
        verify_string = 'REGISTERING'
        return self.verify_string_match(command, verify_string)

    def verify_asa_license_authorized(self):
        """
        Purpose:    To verify smart license AUTHORIZED
        Parameters: ParamikoSSH class object, Default password, New Password
        Returns:    SUCCESS, None
        Raises:
        """
        command = 'show license features | grep enforce'
        verify_string = 'enforce mode: Authorized'
        return self.verify_string_match(command, verify_string)

    def verify_aws_licensing(self):
        """
        Purpose:    To verify AWS Licensing
        Parameters: ParamikoSSH class object, Default password, New Password
        Returns:    SUCCESS, None
        Raises:
        """
        command = 'show license features | grep License'
        verify_string = 'AWS Licensing'
        return self.verify_string_match(command, verify_string)

    def verify_asav_payg_licensed(self):
        """
        Purpose:    To verify ASAv is Licensed
        Parameters: ParamikoSSH class object, Default password, New Password
        Returns:    SUCCESS, None
        Raises:
        """
        command = 'show license features | grep License'
        verify_string = 'License state: LICENSED'
        return self.verify_string_match(command, verify_string)

    def verify_asav_byol_licensed(self):
        """
        Purpose:    To verify ASAv is Licensed
        Parameters: ParamikoSSH class object, Default password, New Password
        Returns:    SUCCESS, None
        Raises:
        """
        command = 'show license features | grep License'
        verify_string = 'ASAv Platform License State: Licensed'
        return self.verify_string_match(command, verify_string)

    def verify_asa_smart_licensing_enabled(self):
        """
        Purpose:    To verify smart license ENABLED
        Parameters: ParamikoSSH class object, Default password, New Password
        Returns:    SUCCESS, None
        Raises:
        """
        command = 'show license features | grep License'
        verify_string = 'License mode: Smart Licensing'
        return self.verify_string_match(command, verify_string)

    def verify_at_least_one_nat_policy_present(self):
        """
        Purpose:    To verify if at least one NAT policy present
        Parameters: ParamikoSSH class object, Default password, New Password
        Returns:    SUCCESS, None
        Raises:
        """
        command = 'show nat'
        verify_string = 'translate_hits'
        return self.verify_string_match(command, verify_string)

    def poll_asa_license_authorized(self, minutes):
        """
        Purpose:    To poll ASAv for Licensing
        Parameters: Minutes
        Returns:    SUCCESS, TIMEOUT
        Raises:
        """
        logger.info("Checking if instance license is AUTHORIZED")
        if minutes <= 1:
            minutes = 2
        for i in range(1, 2 * minutes):
            if i != ((2 * minutes) - 1):
                status = self.verify_asa_license_authorized()
                if status != "SUCCESS":
                    logger.debug(str(i) + " Sleeping for 15 seconds")
                    time.sleep(1 * 15)
                else:
                    return "SUCCESS"
        return "TIMEOUT"

    # fixme This operation is inconsistent hence NOT SUPPORTED,
    #  Any breakage in Communication, can cause ASAv to be terminated without de-register license.
    def deregister_smart_license(self):
        """
        Purpose:    To deregister smart license
        Parameters: ParamikoSSH class object, Default password, New Password
        Returns:    SUCCESS, None
        Raises:
        """
        cmd1 = 'show license status'
        cmd2 = 'license smart deregister'
        cnt_asa = self.connect_asa()
        write_memory_config = 'copy /noconfirm running-config startup-config'
        expected_outcome_write_memory_config = '#'
        command_set = {
            "cmd": [
                {
                    "command": "enable",
                    "expect": "Password:"
                },
                {
                    "command": self.password,
                    "expect": "#"
                },
                {
                    "command": "conf t",
                    "expect": "#"
                },
                {
                    "command": cmd2,
                    "expect": "#"
                },
                {
                    "command": write_memory_config,
                    "expect": expected_outcome_write_memory_config
                }
            ]
        }
        # logger.info("Initiating de-registration of ASAv with command set: "
        #             + json.dumps(command_set, separators=(',', ':')))
        try:
            cnt_asa.handle_interactive_session(command_set, self.username, self.password)
        except ValueError as e:
            logger.error("Error occurred: {}".format(repr(e)))
            return self.FAIL
        else:
            return self.SUCCESS
        finally:
            cnt_asa.close()

    def run_copy_file_running_config(self, url, file_path):
        """
        Purpose:    To change configure running-config from HTTP/HTTPS
        Parameters: url, s3 bucket/any http server path
        Returns:    SUCCESS, None
        Raises:
        """
        cmd1 = 'copy /noconfirm ' + url + ' ' + file_path
        cmd2 = 'copy /noconfirm ' + file_path + ' running-config'
        write_memory_config = 'copy /noconfirm running-config startup-config'
        expected_outcome_write_memory_config = '#'
        command_set = {
            "cmd": [
                {
                    "command": "enable",
                    "expect": "Password:"
                },
                {
                    "command": self.password,
                    "expect": "#"
                },
                {
                    "command": "conf t",
                    "expect": "#"
                },
                {
                    "command": cmd1,
                    "expect": "#"
                },
                {
                    "command": cmd2,
                    "expect": "#"
                },
                {
                    "command": write_memory_config,
                    "expect": expected_outcome_write_memory_config
                }
            ]
        }
        # Do not print below log, will print password on log
        # logger.info("Initiating configuration of ASAv with command set: "
        #             + json.dumps(command_set, separators=(',', ':')))
        logger.info("Executing commands: " + cmd1)
        logger.info("Executing commands: " + cmd2)
        cnt_asa = self.connect_asa()
        try:
            cnt_asa.handle_interactive_session(command_set, self.username, self.password)
        except ValueError as e:
            logger.error("Error occurred: {}".format(repr(e)))
            return None
        else:
            return 'SUCCESS'
        finally:
            cnt_asa.close()



class ParamikoSSH:
    """
        This Python class supposed to handle interactive SSH session
    """
    def __init__(self, server, port=22, username='admin', password=None, id = "1234"):
        self.ssh = paramiko.SSHClient()
        self.ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        self.port = port
        self.server = server
        self.username = username
        self.password = password
        self.timeout = 30
        self.SUCCESS = 'SUCCESS'
        self.FAIL = 'FAILURE'
        self.AUTH_EXCEPTION = 'Authentication Exception Occurred'
        self.BAD_HOST_KEY_EXCEPTION = 'Bad Key Exception occurred'
        self.SSH_EXCEPTION = 'SSH Exception Occurred'
        self.id = id

    def close(self):
        self.ssh.close()

    def verify_server_ip(self):
        try:
            socket.inet_aton(self.server)
            return self.SUCCESS
        except socket.error as e:
            logger.error("Exception occurred: {}".format(repr(e)))
            return self.FAIL
        except Exception as e:
            logger.error("Exception occurred: {}".format(repr(e)))
            return self.FAIL

    def connect(self, username, password):
        """
        Purpose:    Opens a connection to server
        Returns:    Success or failure, if failure then returns specific error
                    self.SUCCESS = 'SUCCESS'
                    self.FAIL = 'FAILURE'
                    self.AUTH_EXCEPTION = 'Authentication Exception Occurred'
                    self.BAD_HOST_KEY_EXCEPTION = 'Bad Key Exception occurred'
                    self.SSH_EXCEPTION = 'SSH Exception Occurred'
        """
        if self.verify_server_ip() == 'FAILURE':
            return self.FAIL
        try:
            self.ssh.connect(self.server, self.port, username, password, timeout=10)
            logger.debug("Connection to %s on port %s is successful!" % (self.server, self.port))
            return self.SUCCESS
        except paramiko.AuthenticationException as exc:
            logger.warn("Exception occurred: {}".format(repr(exc)))
            return self.AUTH_EXCEPTION
        except paramiko.BadHostKeyException as exc:
            logger.debug("Exception occurred: {}".format(repr(exc)))
            return self.BAD_HOST_KEY_EXCEPTION
        except paramiko.SSHException as exc:
            logger.debug("Exception occurred: {}".format(repr(exc)))
            return self.SSH_EXCEPTION
        except BaseException as exc:
            logger.debug("Exception occurred: {}".format(repr(exc)))
            return self.FAIL

    def execute_cmd(self, command):
        """
        Purpose:    Performs an interactive shell action
        Parameters: Command
        Returns:    action status, output & error
        """
        if self.connect(self.username, self.password) != self.SUCCESS:
            raise ValueError("Unable to connect to server")
        try:
            ssh_stdin, ssh_stdout, ssh_stderr = self.ssh.exec_command(command, timeout=30)
        except paramiko.SSHException as exc:
            logger.error("Exception occurred: {}".format(repr(exc)))
            self.ssh.close()
            return self.FAIL, None, None
        else:
            output = ssh_stdout.readlines()
            error = ssh_stderr.readlines()
            logger.debug('SSH command output: ' + str(output))
            self.ssh.close()
            return self.SUCCESS, str(output), str(error)

    def invoke_interactive_shell(self):
        """
        Purpose:    Performs an interactive shell action
        Parameters:
        Returns:    a new Channel connected to the remote shell
        """
        try:
            shell = self.ssh.invoke_shell()
        except paramiko.SSHException as exc:
            send_message(self.id, "Exception occurred: {}".format(repr(exc)))
            self.ssh.close()
            return self.FAIL, None
        else:
            return self.SUCCESS, shell

    def handle_interactive_session(self, command_set, username, password):
        """
        Purpose:    Performs an interactive shell action
        Parameters:
            command_set: a dict of set of commands expressed in command & expect values
            Example:
                {
                  "cmd1": [
                    {
                      "command": "configure password",
                      "expect": "Enter current password:"
                    },
                    {
                      "command": "Cisco123789!",
                      "expect": "Enter new password:"
                    },
                    {
                      "command": "Cisco@123123",
                      "expect": "Confirm new password:"
                    },
                    {
                      "command": "Cisco@123123",
                      "expect": "Password Update successful"
                    }
                  ]
                }
        Returns:
        Raises:
            ValueError based on the error
        """
        if self.connect(username, password) != self.SUCCESS:
            raise ValueError("Unable to connect to server")
        status, shell = self.invoke_interactive_shell()
        if status != self.SUCCESS:
            raise ValueError("Unable to invoke shell")
        if self.send_cmd_and_wait_for_execution(shell, '\n') is not None:
            for key in command_set:
                set = command_set[key]
                for i in range(0, len(set)):
                    command = set[i]['command'] + '\n'
                    expect = set[i]['expect']
                    if self.send_cmd_and_wait_for_execution(shell, command, expect) is not None:
                        pass
                    else:
                        if password in command:
                            raise ValueError("Unable to pass the Password!")
                        else:
                            raise ValueError("Unable to execute command! : {}".format(command))
        else:
            send_message(self.id, "Error in handle_interactive_session")
        return

    def send_cmd_and_wait_for_execution(self, shell, command, wait_string='>'):
        """
        Purpose:    Sends command and waits for string to be received
        Parameters: command, wait_string
        Returns:    rcv_buffer or None
        Raises:
        """
        shell.settimeout(self.timeout)
        total_msg = ""
        rcv_buffer = b""
        try:
            shell.send(command)
            while wait_string not in rcv_buffer.decode("utf-8"):
                rcv_buffer = shell.recv(10000)
                #total_msg = total_msg + ' ' + rcv_buffer.decode("utf-8")
                total_msg = total_msg + rcv_buffer.decode("utf-8")
                # send_message(self.id, "send_cmd_and_wait_for_execution: Command:{}, Wait string:{}".format(command, wait_string))

            return total_msg

        except Exception as e:
            send_message(self.id, "Error occurred in send_cmd_and_wait_for_execution: {}".format(repr(e)))
            send_message(self.id, "ASAv Terminal Output : {}".format(total_msg))
            return None
